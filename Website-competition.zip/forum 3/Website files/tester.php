<!DOCTYPE html>
 <?php  
 include("connection.php");
 $query = "SELECT area, count(*) as number FROM users GROUP BY area"; 
 $query2 = "SELECT Industry, Percentage FROM employe_statistics GROUP BY Industry";
 $result = mysqli_query($conn, $query);  
 $result2 = mysqli_query($conn,$query2);
 ?>  
    <html>
        <head>
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Kaushan+Script'>
            <link rel="stylesheet" href="forum.css">
            <link rel="stylesheet" href="compass.css">
            <link rel="stylesheet" href="tester.css">
                <style>
               

                </style>
            <title>
                Welcome!
            </title>
            
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart1);  
		   google.charts.setOnLoadCallback(drawChart2);  
           function drawChart1()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Area', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["area"]."', ".$row["number"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage of interest per sector',  
                      is3D:true,  
                      //pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
		    function drawChart2()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Industry', 'Percentage'],  
                          <?php  
                          while($row = mysqli_fetch_array($result2))  
                          {  
                               echo "['".$row["Industry"]."', ".$row["Percentage"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage of employee per sector',  
                      is3D:true,  
                      //pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart2'));  
                chart.draw(data, options);  
           }  
           </script>  
        </head>
        <body>
        
		<div>	<?php
              include('header.php');
            ?> </div>

            <div id="container">
                <div class="slider" >
                     <img id="" src="trans.png" height="300">
                </div>
                    <div class="wrap">
                            <div class="blocks">
                                <p class="title"> <b>Stay Updated!</b></p>
                                <p> Get the latest news about job offers as soon as they are proposed! Subscribe to our newsletter and get fast notifications!</p>
                                <div class="btn">
                                    <button  align="center"> <a href="register.php" style="text-decoration:none;">Subscribe</a></button>
                                </div>
                            </div>
                            <div class="blocks">
                               
                                <p class="title"> <b >Join Us!</b></p>
                                <p> Register or Log-in now to have easy access to job offers and communicate with employers or people with similar field interests as yours.</p>
                                <div class="btn">
                                    <button align="center"><a href="register.php" style="text-decoration:none;">Register</a> </button>
                                </div>
                            </div>
                            <div class="blocks">
                                <p class="title"><b>React to posts!</b> </p>
                                <p>Comment/suggest different paths to others to guide them towards their career or get guidance from others now! Become a member to react to other's posts</p>
                                <div class="btn">
                                    <button align="center"> <a href="browse.php" style="text-decoration:none;">Review!</a></button>
                                </div>
                           </div>
                    </div>
                    
                    <div class="blockhome">
                       
                        <div class="module complete-your-profile">
                        <div class="module-content MPU-height-fix">
                             <h2 class="module-heading">Let us guide you to your career!</h2>
                            <div class="module-column left">
                                <h4>Let us do the hard work</h4>
                                <p>Create your profile now to get noticed and we’ll help you find the job you’ve always wanted. With our help, open the door to countless job opportunities with an extensive list of registered employers.</p>
                            </div>
                            <div class="module-column right">
                                <ul>
                                    <li>
                                        <a href="register.php" class="ask-the-experts button" title="Register Now">
                                            Register Now<span class="arrow-white"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="login.php" class="interview-tips button" title="Login">
                                            Login<span class="arrow-white"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="browse.php" class="cv-tips button" title="Create Job Alert">
                                            Choose a field<span class="arrow-white"></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    </div>
                 <div style="width:900px;">  
                     <div id="piechart" style="width: 900px; height: 500px;"></div>  
                 </div>  

           <div style="width:900px;">  
                
                <div id="piechart2" style="width: 900px; height: 500px;"></div>  
           </div>  
            </div>
            
        </div>  
 </div>
 
         
        <div>
           <?php
		   include("footer.php");
		   ?>
        </div>  
 </div>
 
        </body>
        
    </html>
   