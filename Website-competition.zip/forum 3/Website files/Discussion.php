<!DOCTYPE html>
    <html>
        <head>
         <?php
         include('connection.php');
         
         ?>
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Kaushan+Script'>
            <link rel="stylesheet" href="forum.css">
            
            
                <style>
                html {
                font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
                background: url(grey.jpg) no-repeat center center fixed;
                -webkit-background-size: cover;
                -o-background-size: cover;
                background-size: cover;
                }
                #container{
                width: 1000px;
                
                margin: auto;
                overflow: hidden;
                clear: both;
                
                }
                .header{
                background-color:#00004d;
                height:70px;
                overflow: hidden;
                }
                .header a {
                float: right;
                color: black;
                text-align: center;
                padding: 21px;
                font-size: 18px; 
                text-decoration: none;
                border-radius:5px;
              }
              .header a.logo {
                font-size: 25px;
                font-weight: bold;
              }
              
              .header a:hover {
                background-color: dodgerblue;
                color: black;
              }
              
              .header a.active {
                
                color: white;
                margin-right:205px;
              }
              .header a.activefollow {
                
                color: white;
                margin-right:5px;
              }
              .header-right {
                float: right;
              }
              
              @media screen and (max-width: 500px) {
                .header a {
                  float: none;
                  display: block;
                  text-align: left;
                }
                
                .header-right {
                  float: none;
                }
              }
              .blockhome {
                    margin-top: 300px;
                  border: 1px solid;
                  border-color: #c2c2d6;
                  width: 60%;
                  margin-left: 200px;
                  margin-bottom: 35px;
                  border-radius:5px;
              }
              ul {
  list-style-type: none;
  text-align:center;
}
              .module-heading{
                font-size: 0.875em;
    margin: 0 0 1em;
    padding-top: 1.4em;
    padding-bottom: 1em;
    letter-spacing: 1px;
    font-weight: 500;
    text-transform: uppercase;
    border-bottom: 3px solid #043c76;
              }
                  .ask-the-experts {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
.interview-tips {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
                .button {
    display: inline-block;
    zoom: 1;
    *display: inline;
    padding: 0.6em;
    margin: 0 0 0.5em 0;
    font-weight: 700;
    text-decoration: none;
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    border-radius: 6px;
}
.cv-tips {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
.slider {
  width: 70%;
  height: 100%;
  background: url(career.jpg);
  margin: 10px auto;
  animation: slide 20s infinite;
}

@keyframes slide {
  25% {
    background: url(career2.jpg);
  }
  50% {
    background: url(career3.jpg);
  }
  75% {
    background: url(career.jpg);
  }
  10% {
    background: url(career2.jpg);
  }
}
#logo{
    color:#ffffff;
    font-family:'Kaushan Script',cursive;
    font-size:30px;
    float:left;
    padding-right:480px;
    padding-top:10px;
}
.inliner{
   display:inline;
}
//.disctitle{
 border-style:solid;
 border-width:1px;
 text-align:center;
 margin-left:150px;
 margin-right:150px;
 margin-top:50px;
 background-color:lightblue;
 padding-top:10px;
 padding-bottom:10px;
 font-family: bebas_neueregular,sans-serif;
     font-size: 3.6rem;
     color:white;
}
.questn{
 background-color:#96a702;
 
}
.question{
margin-right:50px;
margin-left:50px;
margin-top:50px;

}
table{
  border-collapse:collapse;
   border-radius:2px; 
}
h1 {
    background: 0 0;
    padding: 0;
    min-height: 0;
    line-height: 34px;
    vertical-align: text-bottom;
    display: inline-block;
	color:white;
}
.quest{
	background-color:white;
	height:100px;
}
.like{
 border-radius:2px;
 background-color:lightblue;
}
.dislike{
 background-color: #ff6666;
}
.dislike:hover{
 background-color:#ff0000;
}
.breadcrumb {
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 1rem;
    list-style: none;
    background-color: #f2f2f2;
    border-radius: .25rem;
    padding: .75rem 1rem;
}
.breadcrumb-item {
    padding-left: .5rem;
}
.breadcrumb-item::before {
    display: inline-block;
    padding-right: .5rem;
    color: #6c757d;
    content: ">";
}

input[type="text"] {
    width: 400px;
    height: 100px;
}
a{
	text-decoration:none;
}
                </style>
                <script>
                 function removeone(){
                  var x=document.getElementById('remthisone').innerHTML;
                  x++;
                  document.getElementById('remthisone').innerHTML=x;
                  
                  if(x>=10){
                   alert('This post has received too many reports and must be reviewed by an admin');
                   window.location='tester.php';
                  /*<?php
                  $select_query="select * from field where fieldID=1";
                  $sql=mysqli_query($conn,$select_query);
                  while($row=mysqli_fetch_array($sql))
                  {
                   
                      $id=$row['fieldID'];
                      $title=$row['title'];
                      $quest=$row['Question'];
                       //$del="DELETE FROM field where fieldID='$id'";
                       //$sql=mysqli_query($conn,$del);
                       $id++;
                       $ins="INSERT INTO reported VALUES ('$id','$title','$quest')";
                       $sqlins=mysqli_query($conn,$ins);
                  }
                  ?>
                  */
                  }
                  }
                 
                 function addone(){
                  var foo=document.getElementById('thisone').innerHTML;
                  foo++;
                  document.getElementById('thisone').innerHTML=foo;
                 }
                 </script>
                
            <title>
                Discussion
            </title>
        </head>
        <body>
            <div class="header">
              <?php include('header.php');
              ?>
               <!-- <div class="header-right">
                  <div id="logo">MauCareer<span style="color:orange;">.mu</span> </div>
                  <a class="active" href="register.php">Account</a>
                  <a class="activefollow" href="browse.php">Discussions</a>
                  <a class="activefollow" href="browse.php">Browse Jobs</a>
                  <a class="activefollow" href="index.php">Home</a>
                  
                </div>-->
            </div>
            <div id="container">
               <div class="disctitle">
                <ol class="breadcrumb">
                 <li class="breadcrumb-items"><a href="index.php">Home</a></li>
                 <li class="breadcrumb-item"><a href="browse.php"> Browse QA</a></li>
                 <li class="active breadcrumb-item">  <?php
                            $select_query="select title from field where fieldID=1";
                            $sql=mysqli_query($conn,$select_query);
                            
							
							while($row=mysqli_fetch_array($sql))
                            {
    echo $row['title']."<br>";
}
                        ?>     </li>
                </ol>
               </div>
               <div>
                    <table border="0" class="question">
                     <tr>
                      <td class="questn" rowspan=2> <img src="big.jpg" width="100" height="100" ></td>
                      <td class="questn" style="text-align: center;" rowspan=2> <h1>IT field:Computer Science</h1></td>
                      <td class="questn"> Posted 24 Minutes ago <br> Tags:IT,CS,Technology</td>
                     </tr>
                     <tr>
                     
					  
					  
					  
                     </tr>
					<tr>
					<td colspan=3 class="quest"> <?php
                            $select_query="select question from field where fieldID=1";
                            $sql=mysqli_query($conn,$select_query);
                            
							
							while($row=mysqli_fetch_array($sql))
                            {
    echo $row['question']."<br>";
}
                        ?>   </td>
					</tr>
                     <tr>  
                     <td>
                      <button onclick="addone()" type="button" class="like">Vote Up!</button>
                       <span id="thisone">5 </span>
                     </td>
                     <td> </td>
                     <td>
                      <button onclick="removeone()" type="button" class="dislike">Report post</button>
                       <span id="remthisone">4</span>
                      
                     </td>
                     </tr>
                    </table>
					
                    </div>
                    
                    <table class="quest question">
                     <tr> <td> Reactions:</td> </tr>
                     <tr>
                      <td rowspan=2 > <img src="pic1.jpg" width="100" height="100" ></td>
                      <td> Nier Automata</td>
                     </tr>
                     <tr> <td>  Hi, i am also from the same field as you and have similar qualifications. I would suggest you to apply to the following companies for more career options:Random Company A, Random Company B </td></tr>
                     
                     <hr>
                     <tr> <td><hr></td><td><hr></td></tr>
                     <tr>
                      <td rowspan=2 > <img src="ppic.png" width="100" height="100"> </td>
                      <td> Anonymous </td>
                     </tr>
                     <tr> <td> Nier is right,as you might have heard before, Random Company A is one of the best in the country to expand your knowledge areas. I highly recommend it too. </td></tr>
                     
                     <?php
                    $retrieve="SELECT * FROM comment WHERE fieldID=1";
                      $retrieveResult = mysqli_query($conn, $retrieve);
                       while($row=mysqli_fetch_array($retrieveResult))
                            {
                            
                        ?>                
                    
                     <tr> <td><hr></td><td><hr></td></tr>
                     <tr>
                      <td rowspan=2 > <img src="ppic.png" width="100" height="100"> </td>
                      <td> <?php echo $row['name']; ?> </td>
                     </tr>
                     <tr> <td> <?php echo $row['comments']; ?> </td></tr>
                     <?php
                    }
                    ?>
                    </table>
                    <?php
                    if(isset($_SESSION['login'])){
                     echo ' <form>
                    <table class="question" method="get">
                     <tr> <td> Respond to this thread: </td></tr>
                      <tr> <td> Name </td></tr>
                     <tr> <td > <input type="textbox" name="name" id="name"> </td></tr>
                      <tr> <td> Comment</td></tr>
                     <tr> <td > <input type="text" name="comment"> </td></tr>
                     
                     <tr> <td> <input type="submit" value="submit" ></td></TD></tr>
                    </table>
                     </form> ';
                     
                    }
                    
                    if(isset($_GET['name']) && isset($_GET['comment']))
                    {
                    $com= $_GET['comment'];
                     $nam=$_GET['name'];
                     $sql="INSERT INTO comment VALUES(1,'$com','$nam')";
                     $sqlResult = mysqli_query($conn, $sql);
                    }
                    ?>
                    
                    
                    <div class="blockhome">
                       
                        
                    </div>

                    </div>
                
            </div>
            
        </div>  
 </div>
 <?php
 include('footer.php');
 ?>
<!--
            <div class="footer">
            <div class="main_footer">
                <div class="col1">
                    <h3>Jobs in Mauritius by Industry Sector</h3>
                  <div class="inliner">
                    <ul><li class="inliner"><a href='/Jobs/Accounting-Auditing-Tax-Services-Finance/'>Accounting / Auditing / Tax Services / Finance</a></li><li><a href='/Jobs/Administrative-Clerical/'>Administrative / Clerical</a></li><li><a href='/Jobs/Advertising/'>Advertising</a></li><li><a href='/Jobs/Agriculture-Fishing/'>Agriculture / Fishing</a></li><li><a href='/Jobs/Banking/'>Banking</a></li><li><a href='/Jobs/Call-Centers-BPO-Customer-Service-Languages/'>Call Centers / BPO / Customer Service / Languages</a></li><li><a href='/Jobs/Construction-Architecture-Property/'>Construction / Architecture / Property</a></li><li><a href='/Jobs/Consulting/'>Consulting</a></li><li><a href='/Jobs/Education-Training-Course/'>Education / Training Course</a></li><li><a href='/Jobs/Engineering-Electronics-Mechanics/'>Engineering / Electronics / Mechanics</a></li><li><a href='/Jobs/Environmental-Health-and-Safety-Quality/'>Environmental / Health and Safety / Quality</a></li><li><a href='/Jobs/Food-Beverages-Catering/'>Food / Beverages / Catering</a></li></ul>
                  </div>
                   <h3>Contact Us</h3>
                    <ul>
                        <li><a href="#">Email</a></li>
                    </ul>
                </div>
                <div class="col2">
                    <h3> <br></h3>
                   <ul><li class="inliner"><a href='/Jobs/Graphic-Design/'>Graphic Design</a></li><li><a href='/Jobs/Healthcare-Medical-Veterinary/'>Healthcare / Medical / Veterinary</a></li><li><a href='/Jobs/HR-Recruiting/'>HR / Recruiting</a></li><li><a href='/Jobs/ICT-IT-Web/'>ICT / IT / Web</a></li><li><a href='/Jobs/Import-Export/'>Import / Export</a></li><li><a href='/Jobs/Insurance/'>Insurance</a></li><li><a href='/Jobs/Legal/'>Legal</a></li><li><a href='/Jobs/Logistics-Warehousing-Distribution-Transport/'>Logistics / Warehousing / Distribution / Transport</a></li><li><a href='/Jobs/Management/'>Management</a></li><li><a href='/Jobs/Manufacturing-Production/'>Manufacturing / Production</a></li><li><a href='/Jobs/Marketing-Sales/'>Marketing / Sales</a></li><li><a href='/Jobs/Non-profit/'>Non profit</a></li></ul>
                </div>
                <div class="col3">
                    <h3><br></h3>
                    <ul><li><a href='/Jobs/Pharmaceutical-Science/'>Pharmaceutical / Science</a></li><li><a href='/Jobs/Public-Relation-Communication/'>Public Relation / Communication</a></li><li><a href='/Jobs/Public-Sector/'>Public Sector</a></li><li><a href='/Jobs/Purchasing/'>Purchasing</a></li><li><a href='/Jobs/Security-Protective-Services/'>Security / Protective Services</a></li><li><a href='/Jobs/Social-Services-Community/'>Social Services / Community</a></li><li><a href='/Jobs/Spa/'>Spa</a></li><li><a href='/Jobs/Sports-Leisure-Arts/'>Sports / Leisure / Arts</a></li><li><a href='/Jobs/Telecommunications/'>Telecommunications</a></li><li><a href='/Jobs/Textile/'>Textile</a></li><li><a href='/Jobs/Tourism-Travel/'>Tourism / Travel</a></li><li><a href='/Jobs/Training/'>Training</a></li></ul>

                    
                </div>
                
                  
               
            </div>-->
        </div>  
 </div>
        </body>
        
    </html>
   