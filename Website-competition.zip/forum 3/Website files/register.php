<!DOCTYPE html>
<html lang="en">
<head>
<?php
include('connection.php');
?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="captcha.css"> <!-- The directory of the CSS file -->
    <script type="text/javascript" src="captcha.js"></script>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body onLoad="ChangeCaptcha()">
    <div class="main">

        <section class="signup">
            <!-- <img src="images/signup-bg.jpg" alt=""> -->
            <div class="container">
                <div class="signup-content">
                    <form method="GET" id="signup-form" class="signup-form"">
                        <h2 class="form-title">Create account</h2>
                        <div class="form-group">
                            <input type="text" class="form-input" name="name" id="name" placeholder="Your Name"/>
                        </div>
                        <div class="form-group">
                            <input type="texr" class="form-input" name="username" id="username" placeholder="Username"/>
                        </div>
						 <div class="form-group">
                            <input type="email" class="form-input" name="email" id="email" placeholder="Your Email"/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="password" id="password" placeholder="Password"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="re_password" id="re_password" placeholder="Repeat your password"/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="area" id="area" placeholder="Courses completed, Academic and Research interests " height=20/>
                        </div>
                        <input type="text" id="randomfield" disabled>
		<br><br>
		<input id="CaptchaEnter" size="20" maxlength="6" /> <!-- Change maxlength to the size you wanted your Captcha to be -->
		<br><br>
                        <div class="form-group">
                            <input onclick="check()" type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
                        </div>
                    </form>
                    <p class="loginhere">
                        Have already an account ? <a href="login.php" class="loginhere-link">Login here</a>
                    </p>
					<p class="loginhere">
                        Changed your mind ? <a href="index.php" class="loginhere-link">Go Home</a>
                    </p>
                </div>
            </div>
        </section>

    </div>
<?php
 error_reporting(0);
 if(isset($_GET['submit']))
 {
  $name = $_GET['name'];
  $username = $_GET['username'];
  $email = $_GET['email'];
  $pw = $_GET['re_password'];
  $area=$_GET['area'];
   $check="SELECT * FROM users WHERE Email='$email'" ;
   $exec=mysqli_query($conn,$check);
   $num_rows=mysqli_num_rows($exec);
   if($num_rows>0)
   {
    echo "<script> alert('The user has already been previously registered in the database');window.location='register.php';</script>";
    
   }
   else if($name!="" && $username!="" && $email!="" && $pw!=""){
    $pw=md5($pw);
    $email=md5($email);
   $query = "INSERT INTO users VALUES('$username','$pw','$email','$name','$area')";
   $data = mysqli_query($conn,$query);
   if($data){
    $_SESSION["login"]="OK";
    echo "<script> alert('successful registration');window.location='index.php';</script>";
   }
   else 
   {
    echo "<script> alert('User already registered');window.location='register.php';</script>";
   }
   
	}
 }
 ?>
	
    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>