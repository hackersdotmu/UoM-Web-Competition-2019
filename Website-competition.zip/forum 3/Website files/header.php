<?php
error_reporting(0);
session_start();
?> 


            <link rel="stylesheet" href="compass.css">
            <link rel="stylesheet" href="tester.css">
<div class="header">
              
                <div class="header-right">
                  <div id="logox">MauCareer<span style="color:orange;">.mu</span> </div>
				  
                  <a class="active" 
				<?php
                if(isset($_SESSION["login"]))
                {
                echo ' href="account.php" ';
                }
                else {
                 echo' 
                  href="login.php"';
                }
                ?>
				>Account</a>
				 
				  
                  <a class="activefollow" href="browse.php">Discussions</a>
                  <a class="activefollow" href="index.php">Home</a>
                  
                </div>
</div>