<?php
   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "forum";
   session_start();
   $conn = mysqli_connect($servername,$username,$password,$dbname);
   if($conn){
   // echo "Connection successful";
   }
   else
   {
    die("Connection failed because ".mysqli_connect_error());
   }
   function connect()
   {
	$conn = mysqli_connect('localhost','root','','website');
   if(!$conn){
   // echo "Connection successful";
   die("Connection failed because ".mysqli_connect_error());
   }
   return $conn;
   }
   
   function get_suggestions($search){
	   $connection = connect();
	   $sql = "SELECT * FROM product WHERE name LIKE '%$search%'";
	   $result = mysqli_query($connection,$sql);
	   
	   if(mysqli_num_rows($result))
	   {
		   return mysqli_fetch_all($result, MYSQLI_ASSOC);
	   }
	   return false;  
   }
   function debug($args)
   {
	   echo '<pre>';
	   print_r($args);
	   echo '<pre>';
	   exit;
   
   }
   
 ?>  