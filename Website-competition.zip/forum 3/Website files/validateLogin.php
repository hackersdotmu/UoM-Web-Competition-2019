<?php


include("connection.php");

if (isset($_POST['submit'])){

    $user = $_POST['username'];
    $pwd = $_POST['pass'];
    $_SESSION['username']=$user;
echo "{$user}";
echo "{$pwd}";

    $log = "SELECT * FROM users WHERE Username = '$user' && Password = '$pwd' ";
    $logResult = mysqli_query($conn, $log);
    
    
     if(mysqli_num_rows($logResult) <1){
		
		echo "<script type='text/javascript'>alert('invalid Username or password');window.location='index.php';</script>";
		 }


     else
		 {
       if(mysqli_num_rows($logResult) > 0 )
       {
		  
         $_SESSION["login"] = $logResult  ;
         echo "<script type='text/javascript'>alert('User logged in');window.location='index.php';</script>";
         
         
        
       }

     }

     mysqli_close($conn);


}

?>
