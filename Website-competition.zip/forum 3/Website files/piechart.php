<?php  
 include("connection.php");
 $query = "SELECT area, count(*) as number FROM users GROUP BY area"; 
$query2 = "SELECT Industry, Percentage FROM employe_statistics GROUP BY Industry";
 $result = mysqli_query($conn, $query);  
 $result2 = mysqli_query($conn,$query2);
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Make Simple Pie Chart by Google Chart API with PHP Mysql</title>  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart1);  
		   google.charts.setOnLoadCallback(drawChart2);  
           function drawChart1()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Area', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["area"]."', ".$row["number"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage of interest per sector',  
                      is3D:true,  
                      //pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
		    function drawChart2()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Industry', 'Percentage'],  
                          <?php  
                          while($row = mysqli_fetch_array($result2))  
                          {  
                               echo "['".$row["Industry"]."', ".$row["Percentage"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage of interes per sector',  
                      is3D:true,  
                      //pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart2'));  
                chart.draw(data, options);  
           }  
           </script>  
      </head>  
      <body>  
           <br /><br />  
           <div style="width:900px;">  
                <h3 align="center">Make Simple Pie Chart by Google Chart API with PHP Mysql</h3>  
                <br />  
                <div id="piechart" style="width: 900px; height: 500px;"></div>  
           </div>  
		   <br /><br />  
           <div style="width:900px;margin-left: 1000px;margin-top:-600px;">  
                <h3 align="center">Make Simple Pie Chart by Google Chart API with PHP Mysql</h3>  
                <br />  
                <div id="piechart2" style="width: 900px; height: 500px;"></div>  
           </div>  
      </body>  
 </html>  