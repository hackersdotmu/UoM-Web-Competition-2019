<!DOCTYPE html>
 <?php  
 include("connection.php");
 
 $query = "SELECT area, count(*) as number FROM users GROUP BY area"; 
$query2 = "SELECT Industry, Percentage FROM employe_statistics GROUP BY Industry";
 $result = mysqli_query($conn, $query);  
 $result2 = mysqli_query($conn,$query2);
 ?>  
    <html>
        <head>
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Kaushan+Script'>
            <link rel="stylesheet" href="forum.css">
            <link rel="stylesheet" href="compass.css">
            <link rel="stylesheet" href="tester.css">
                <style>
               .breadcrumb {
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 1rem;
    list-style: none;
    background-color: #f2f2f2;
    border-radius: .25rem;
    padding: .75rem 1rem;
}
.breadcrumb-item {
    padding-left: .5rem;
}
.breadcrumb-item::before {
    display: inline-block;
    padding-right: .5rem;
    color: #6c757d;
    content: ">";
}

                </style>
            <title>
                Browse
            </title>
            
        </head>
        <body>
        
 <div>
			<?php
              include('header.php');
            ?>
            </div>
      <div id="container">
            <ol class="breadcrumb">
              <li>Home</li>
              <li class="breadcrumb-item">Browse QA</li>
             </ol>
            
            <table style="width:500px;text-align: center;">
             <th> <span>Sekter dans Moris:</span></th>
             <tr><td><a href="create.php?field=agrikiltire" > Agrilkiltire</a></td></tr>
             <tr><td><a href="discussion.php">Teknolozie </a></td></tr>
              <tr><td> <a href="create.php?field=finans">Finans      </td></tr>
              <tr><td><a href="create.php?field=nouritire"> Nouritire      </td></tr>
              <tr><td><a href="create.php?field=lasirance"> Lasirance      </td></tr>
              <tr><td> <a href="create.php?field=ledikasion">Ledikasion      </td></tr>
              <tr><td> <a href="create.php?field=transport">Transport      </td></tr>
              <tr><td><a href="create.php?field=sport"> Sport      </td></tr>
              <tr><td> <a href="create.php?field=textile">Textile      </td></tr>
              <tr><td> <a href="create.php?field=tourisme">Tourisme      </td></tr>
             
            </table>
             
            
                 </div>
        
     
      </div>
      
        </div>  
 </div>
 
         
            <div class="footer">
            <?php
		   include("footer.php");
		   ?>
                
                  
               
            </div>
        </div>  
 </div>
 
        </body>
        
    </html>
   