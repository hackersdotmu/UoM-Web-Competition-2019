<!DOCTYPE html>
    <html>
        <head>
         <?php
         include('connection.php');
         
         ?>
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Kaushan+Script'>
            <link rel="stylesheet" href="forum.css">
            
            
                <style>
                html {
                font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
                background: url(grey.jpg) no-repeat center center fixed;
                -webkit-background-size: cover;
                -o-background-size: cover;
                background-size: cover;
                }
                #container{
                width: 1000px;
                
                margin: auto;
                overflow: hidden;
                clear: both;
                
                }
                .header{
                background-color:#00004d;
                height:70px;
                overflow: hidden;
                }
                .header a {
                float: right;
                color: black;
                text-align: center;
                padding: 21px;
                font-size: 18px; 
                text-decoration: none;
                border-radius:5px;
              }
              .header a.logo {
                font-size: 25px;
                font-weight: bold;
              }
              
              .header a:hover {
                background-color: dodgerblue;
                color: black;
              }
              
              .header a.active {
                
                color: white;
                margin-right:205px;
              }
              .header a.activefollow {
                
                color: white;
                margin-right:5px;
              }
              .header-right {
                float: right;
              }
              
              @media screen and (max-width: 500px) {
                .header a {
                  float: none;
                  display: block;
                  text-align: left;
                }
                
                .header-right {
                  float: none;
                }
              }
              .blockhome {
                    margin-top: 300px;
                  border: 1px solid;
                  border-color: #c2c2d6;
                  width: 60%;
                  margin-left: 200px;
                  margin-bottom: 35px;
                  border-radius:5px;
              }
              ul {
  list-style-type: none;
  text-align:center;
}
              .module-heading{
                font-size: 0.875em;
    margin: 0 0 1em;
    padding-top: 1.4em;
    padding-bottom: 1em;
    letter-spacing: 1px;
    font-weight: 500;
    text-transform: uppercase;
    border-bottom: 3px solid #043c76;
              }
                  .ask-the-experts {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
.interview-tips {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
                .button {
    display: inline-block;
    zoom: 1;
    *display: inline;
    padding: 0.6em;
    margin: 0 0 0.5em 0;
    font-weight: 700;
    text-decoration: none;
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    border-radius: 6px;
}
.cv-tips {
    color: #fff;
    background: #043c76 url() no-repeat 10px center;
    padding-left: 10px;
}
.slider {
  width: 70%;
  height: 100%;
  background: url(career.jpg);
  margin: 10px auto;
  animation: slide 20s infinite;
}

@keyframes slide {
  25% {
    background: url(career2.jpg);
  }
  50% {
    background: url(career3.jpg);
  }
  75% {
    background: url(career.jpg);
  }
  10% {
    background: url(career2.jpg);
  }
}
#logo{
    color:#ffffff;
    font-family:'Kaushan Script',cursive;
    font-size:30px;
    float:left;
    padding-right:480px;
    padding-top:10px;
}
.inliner{
   display:inline;
}
//.disctitle{
 border-style:solid;
 border-width:1px;
 text-align:center;
 margin-left:150px;
 margin-right:150px;
 margin-top:50px;
 background-color:lightblue;
 padding-top:10px;
 padding-bottom:10px;
 font-family: bebas_neueregular,sans-serif;
     font-size: 3.6rem;
     color:white;
}
.questn{
 background-color:#96a702;
 
}
.question{
margin-right:50px;
margin-left:50px;
margin-top:50px;

}
table{
  border-collapse:collapse;
   border-radius:2px; 
}
h1 {
    background: 0 0;
    padding: 0;
    min-height: 0;
    line-height: 34px;
    vertical-align: text-bottom;
    display: inline-block;
	color:white;
}
.quest{
	background-color:white;
	height:100px;
}
.like{
 border-radius:2px;
 background-color:lightblue;
}
.dislike{
 background-color: #ff6666;
}
.dislike:hover{
 background-color:#ff0000;
}
.breadcrumb {
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 1rem;
    list-style: none;
    background-color: #f2f2f2;
    border-radius: .25rem;
    padding: .75rem 1rem;
}
.breadcrumb-item {
    padding-left: .5rem;
}
.breadcrumb-item::before {
    display: inline-block;
    padding-right: .5rem;
    color: #6c757d;
    content: ">";
}

input[type="text"] {
    width: 400px;
    height: 100px;
}
                </style>
                <script>
                 function removeone(){
                  var x=document.getElementById('remthisone').innerHTML;
                  x++;
                  document.getElementById('remthisone').innerHTML=x;
                  
                  if(x>=10){
                   alert('This post has received too many reports and must be reviewed by an admin');
                   window.location='tester.php';
                  /*<?php
                  $select_query="select * from field where fieldID=1";
                  $sql=mysqli_query($conn,$select_query);
                  while($row=mysqli_fetch_array($sql))
                  {
                   
                      $id=$row['fieldID'];
                      $title=$row['title'];
                      $quest=$row['Question'];
                       //$del="DELETE FROM field where fieldID='$id'";
                       //$sql=mysqli_query($conn,$del);
                       $id++;
                       $ins="INSERT INTO reported VALUES ('$id','$title','$quest')";
                       $sqlins=mysqli_query($conn,$ins);
                  }
                  ?>
                  */
                  }
                  }
                 
                 function addone(){
                  var foo=document.getElementById('thisone').innerHTML;
                  foo++;
                  document.getElementById('thisone').innerHTML=foo;
                 }
                 </script>
                
            <title>
                Discussion
            </title>
        </head>
        <body>
 <div>
			<?php
              include('header.php');
            ?>
            </div>
            <div id="container">
               <div class="disctitle">
                <ol class="breadcrumb">
                 <li class="breadcrumb-items">Home</li>
                 <li class="breadcrumb-item">Browse QA</li>
                 <li class="active breadcrumb-item">  <?php  if(isset($_GET['field'])){
                  $field=$_GET['field'];
                   $_SESSION['field']=$field;
                 }echo $_SESSION['field']; ?></li>
                </ol>
               </div>
               <div>
                    </div>
                    <?php
                          $y=$_SESSION['field'];
                          $finder="SELECT fieldID FROM sector WHERE fname='$y'";
                     $finderexec=mysqli_query($conn,$finder);
                    while($row=mysqli_fetch_array($finderexec)){
                     $fid=$row['fieldID'];
                    }
                    $z="SELECT * FROM field WHERE fieldID='$fid'";
                    $zexec=mysqli_query($conn,$z);
                    while($rowx=mysqli_fetch_array($zexec)){
                     $xtitle=$rowx['title'];
                     $xcom=$rowx['Question'];
                     ?>
                    <table class="quest question">
                      <table border="0" class="question">
                         <tr>
                          <td class="questn" rowspan=2> <img src="ppic.png" width="100" height="100" ></td>
                          <td class="questn" style="text-align: center;" rowspan=2> <h1 id="title"> <?php echo $xtitle; ?></h1></td>
                          <td class="questn"> Posted 0 Min(s) ago <br> Tags:#</td>
                         </tr>
                         <tr>
                         </tr>
                          <tr>
                          <td colspan=3 class="quest" id="comment" > <?php echo $xcom; ?> </td>
                          </tr>
                         <tr>  
                         <td>
                          <button onclick="addone()" type="button" class="like">Vote Up!</button>
                           <span id="thisone">0 </span>
                         </td>
                         <td> </td>
                         <td>
                          <button onclick="removeone()" type="button" class="dislike">Report post</button>
                           <span id="remthisone">0</span>
                          
                         </td>
                         </tr>
                    </table>
                      <?php
                    }
                    ?>
                     
                     <?php
                    if(isset($_GET['comment'])){
                     $x=$_SESSION['field'];
                     $finder="SELECT fieldID FROM sector WHERE fname='$x'";
                     $finderexec=mysqli_query($conn,$finder);
                    while($row=mysqli_fetch_array($finderexec)){
                     $fid=$row['fieldID'];
                    }
                     $name=$_GET['name'];
                     $title=$_GET['title'];
                    $com=$_GET['comment'];
                    $sqlx="INSERT INTO field VALUES ('$fid','$title','$com',0,'$x')";
                    $sqlexec=mysqli_query($conn,$sqlx);
                     
                     ?>
                     
                      <table border="0" class="question">
                         <tr>
                          <td class="questn" rowspan=2> <img src="ppic.png" width="100" height="100" ></td>
                          <td class="questn" style="text-align: center;" rowspan=2> <h1 id="title"> <?php echo $title; ?></h1></td>
                          <td class="questn"> Posted 0 Min(s) ago <br> Tags:#</td>
                         </tr>
                         <tr>
                         </tr>
                          <tr>
                          <td colspan=3 class="quest" id="comment" > <?php echo $com; ?> </td>
                          </tr>
                         <tr>  
                         <td>
                          <button onclick="addone()" type="button" class="like">Vote Up!</button>
                           <span id="thisone">0 </span>
                         </td>
                         <td> </td>
                         <td>
                          <button onclick="removeone()" type="button" class="dislike">Report post</button>
                           <span id="remthisone">0</span>
                          
                         </td>
                         </tr>
                    </table>
                     <?php
                    }
                    ?>
                     
                    </table>
                    <form>
                    <table class="question" method="get">
                     <tr> <td> Add a question to this thread: </td></tr>
                      <tr> <td> Name </td></tr>
                     <tr> <td > <input type="textbox" name="name"> </td></tr>
                     <tr> <td> Title </td></tr>
                     <tr> <td > <input type="textbox" name="title" id="wtitle"> </td></tr>
                      <tr> <td> Comment</td></tr>
                     <tr> <td > <input type="text" name="comment" id="wcom"> </td></tr>
                     
                     <tr> <td> <input type="submit" value="submit" ></td></TD></tr>
                    </table>
                     </form>
                    
                    <div class="blockhome">
                       
                        
                    </div>

                    </div>
                
            </div>
            
        </div>  
 </div>
<br>
            <div class="footer">
            <?php
		   include("footer.php");
		   ?>
        </div>  
 </div>
        </body>
        
    </html>
   