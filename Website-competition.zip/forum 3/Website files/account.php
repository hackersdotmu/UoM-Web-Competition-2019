<!DOCTYPE html>

<html>
<head>

    <title>Customer login/sign up</title>
    <link rel="stylesheet" href="compass2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<div>
        <?php
			include('header.php');
			error_reporting(0);
		?>
    </div>
 
    <div class="main_container" >
        <div class="hero" style="width:100%;">
            <h2 class="login_head" style="position: relative; margin-left:200px; margin-top:-5px;max-width:100%;color:#fff;padding-top:130px;">Update account details</h2>
               <hr width="50%" >
            <form action="login.php" method="POST">
                <table border="0" style="text-align: center;">
                 <tr >
                     <td><h4>Name</h4></td>
                     <td>
                         <?php
                        $email= $_SESSION['Email'];
                        $select_query="SELECT * FROM users WHERE Email='$email'";
                        $sql=mysqli_query($conn,$select_query) ;
                        $row=mysqli_fetch_array($sql);
                         ?>
                         <h4>Name:</h4>
                          <input type="text"  class="changebox" placeholder="<?php echo "{$row['name']}"; ?>" name="name">
                         <h4>Username:</h4>
                          <input type="text"  class="changebox"  placeholder="<?php echo "{$row['Username']}"; ?>" name="uname">                   
                     </td>
                 </tr>
                 
                  <tr>
                     <td><h4>Email:</h4></td>
                     <td> <input type="email"  class="changebox"  placeholder="<?php echo "{$row['Email']}"; ?>" name="Email"></td>
                 </tr>
                 
                  <tr>
                     <td><h4> Update Password:</h4></td>
                     
                     <td>
                        <input type="password"  class="changebox"  placeholder="*Password" name="psw">
                        <input type="password"  class="changebox"  placeholder="*Confirm Password" name="conpsw" >
                     </td>
                 </tr>
                 <tr>
                    <td colspan="2">   
					<input type="submit" style="width:50%;border-radius:30px; " class="join" name="submit" value="submit"> 
					<a  href="account.php?logout=1" style="text-decoration:none;"> Log Out</a>
                       <?php
                        
                        ?>
                       <?php
                      if(isset($_GET['logout'])){
                        
                        echo "<script> window.location='index.php'; </script>";
                        session_unset();
                        session_destroy();
                        unset($_SESSION["login"]);
                       }
                       ?>
					</td>
                 </tr>
                </table>
            </form>
            
                    <?php
                    if(isset($_POST['submit'])){
                        $fn = $_POST['name'];
                        $ln = $_POST['uname'];
                        $em = $_POST['Email'];
                        $pw = $_POST['conpsw'];
    
                        if($fn!="")
                            {
                            $query="UPDATE users SET name='$fn' WHERE Email='$email'";
                            $data = mysqli_query($conn,$query);
                            }
                        if($ln!="")
                            {
                            $query="UPDATE users SET Username='$ln' WHERE Email='$email'";
                            $data = mysqli_query($conn,$query);
                            }
                        if($em!="")
                            {
                            $query="UPDATE users SET Email='$em' WHERE Email='$email'";
                            $data = mysqli_query($conn,$query);
                            }
                        if($pw!="")
                        {
                        $query="UPDATE users SET Password='$pw' WHERE Email='$email'";
                        $data = mysqli_query($conn,$query);
                        echo "<h1> Hello World </h1>";
                        }
                        
                     
                    }
                     
                     ?>
        </div>
    </div>
 
 
 
</body>
</html>
