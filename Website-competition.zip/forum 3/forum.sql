-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 31, 2019 at 05:34 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `fieldID` int(11) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`fieldID`,`comments`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employe_statistics`
--

DROP TABLE IF EXISTS `employe_statistics`;
CREATE TABLE IF NOT EXISTS `employe_statistics` (
  `Industry` varchar(255) NOT NULL,
  `Percentage` float NOT NULL,
  PRIMARY KEY (`Industry`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employe_statistics`
--

INSERT INTO `employe_statistics` (`Industry`, `Percentage`) VALUES
('Accomodation and food service activites', 7),
('Administratice and support services', 4),
('Agriculture', 7),
('Construction', 7),
('Education', 6),
('Manufacturing', 17),
('Other', 21),
('Public Administration', 7),
('Transportation and Storage', 7),
('Wholesale and retail trade', 17);

-- --------------------------------------------------------

--
-- Table structure for table `field`
--

DROP TABLE IF EXISTS `field`;
CREATE TABLE IF NOT EXISTS `field` (
  `fieldID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `Question` varchar(255) NOT NULL,
  `flags` int(11) NOT NULL,
  `field` varchar(255) NOT NULL,
  PRIMARY KEY (`Question`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field`
--

INSERT INTO `field` (`fieldID`, `title`, `Question`, `flags`, `field`) VALUES
(1, 'IT field:Computer Science', 'Hello there, i am new to this website and i want to find jobs in IT..I am qualified in Computer Science with a Bsc from the UoM. I have past experiences in webs development and application development. ', 5, 'Teknolozie'),
(4, 'This is a second test ', 'I am still testing the website at the moment', 0, 'nouritire'),
(4, 'This is a test question', 'testing the question', 0, 'nouritire');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `QuestionsID` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Category` varchar(255) NOT NULL,
  `Question` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Reports` int(11) NOT NULL,
  PRIMARY KEY (`QuestionsID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reported`
--

DROP TABLE IF EXISTS `reported`;
CREATE TABLE IF NOT EXISTS `reported` (
  `fieldID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `Question` varchar(255) NOT NULL,
  PRIMARY KEY (`fieldID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reported`
--

INSERT INTO `reported` (`fieldID`, `title`, `Question`) VALUES
(2, 'Technology', 'Hello there, i am new to this website and i want to find jobs in IT..I am qualified in Computer Science with a Bsc from the UoM. I have past experiences in webs development and application development. ');

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
CREATE TABLE IF NOT EXISTS `sector` (
  `fieldID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  PRIMARY KEY (`fieldID`),
  UNIQUE KEY `fname` (`fname`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`fieldID`, `fname`) VALUES
(1, 'teknolozie'),
(2, 'agrikiltire\r\n'),
(3, 'finans'),
(4, 'nouritire'),
(5, 'lasirance'),
(6, 'ledikasion'),
(7, 'transport'),
(8, 'sport'),
(9, 'textile'),
(10, 'tourisme');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Username`, `Password`, `Email`, `name`, `area`) VALUES
('admin', 'admin', 'test@gmail.com', 'Girish Emerith', 'IT'),
('afdqacf', 'ASD', 'WAFGUYB@WERGEDH.COM', 'Azhix', 'ASDFAF'),
('asfa', 'c0ae0be4436d7fe16ca5cdcf966f3b8e', 'afa@saef.cc', 'afasf', 'fdd'),
('Azhix', 'lol', 'azharbhuheekhan@hotmail.com', 'Azhix', 'Academy'),
('iamanuj03', '12345', 'anuj@gmail,com', 'anuj', 'IT'),
('iamazhar111115', '45673', 'azhcfcar@gmail.com', 'anuj', 'IT'),
('iamazhar122225', '45673', 'azhcfcar@gmail.com', 'anuj', 'Software'),
('iamazhar1335', '45673', 'azharxsx@gmail.com', 'anuj', 'Chemistry'),
('iamazhar144445', '45673', 'azharfvfv@gmail.com', 'anuj', 'finance'),
('iamazhar14555', '45673', 'azharcdc@gmail.com', 'anuj', 'Physics'),
('iamazhar15', '45673', 'azhar@gmail.com', 'anuj', 'IT'),
('iamazhar155', '45673', 'azharfvf@gmail.com', 'anuj', 'graphics'),
('iamazhar1575', '45673', 'azhasxsxr@gmail.com', 'anuj', 'IT'),
('iamazhar165', '45673', 'azharxddxd@gmail.com', 'anuj', 'Telecom'),
('iamazhar16775', '45673', 'azhar54545@gmail.com', 'anuj', 'biology'),
('iamazhar25', '45673', 'azhar3@gmail.com', 'anuj', 'science'),
('iamazhar35', '45673', 'azhar44@gmail.com', 'anuj', 'Agri'),
('iamazhar55', '45673', 'azharfrf@gmail.com', 'anuj', 'Engineering'),
('tester123', 'test', 'testmail@gmail.com', 'tester', 'it');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
